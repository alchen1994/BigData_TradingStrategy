# Read CSV into R
data <- read.csv(file="GOOGL.csv", header=TRUE, sep=",")
semantic <- data$semantic
close <-data$close
date <-data$date
plot(date, semantic, type="o", col="blue",lty=1)
points(date, close, col="red")
lines(date, close, col="red",lty=2)
fit = lm(close ~ semantic)
summary(fit)
#relation <- lm(y~x2)
#summary(relation)

#plot(x0, x1, type="o", col="blue", pch="o", lty=1)

#points(x0, x2, col="red", pch="*")
#lines(x0, x2, col="red",lty=2)

#points(x0, x2, col="dark red",pch="+")
#lines(x0, x2, col="dark red", lty=3)